import { createFileRoute } from '@tanstack/react-router'
import { ScannerDemo } from '@/components/scanner-demo'

export const Route = createFileRoute('/dashboard')({
  component: DashboardComponent,
})

function DashboardComponent() {
  return <ScannerDemo />
}